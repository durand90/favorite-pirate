import React, { useState, useEffect } from 'react'
import axios from 'axios'

import { Link } from 'react-router-dom'




export const Display = () => {



    const [pirates, setPirates] = useState([])

    useEffect(() => {
        axios.get('http://localhost:8000/api/pirates')
            .then(res => {
                console.log(res.data)
                setPirates(res.data)
            })
            .catch(err => console.log(err))
    }, [])

    const deletePirate = (deleteIdx) => {
        console.log('delete working')

        axios.delete('http://localhost:8000/api/pirates/' + deleteIdx)
            .then(res => {
                console.log(res.data)
                setPirates(pirates.filter((pirate) => pirate._id !== deleteIdx));
            })
            .catch(err => console.log(err))
    }

    return (
        <div>
            <div style={{backgroundColor: 'orange'}}>

            {/* <p>{JSON.stringify(pirates)}</p> */}
            <h1 style={{backgroundColor: 'brown'}}>Pirate Crew</h1>
            <button><Link to='/pirate/create'>Add Pirate</Link></button>

            {
                pirates.map((pirate, index) => {
                    return (
                        <div style={{backgroundColor: 'white', width: '400px', height: '200px', margin: '0 auto',
                                    marginBottom: '10px', marginTop: '10px', display: 'flex'}}
                            key={pirate._id}>
                            <img
                                style={{ width: '80px', heigth: '80px' }}
                                src={pirate.image}
                                />
                                <div>
                            <p>{pirate.pirateName}</p>
                            <button style={{backgroundColor: 'blue', color: 'white'}}><Link to={'/pirate/view/' + pirate._id}>view pirate</Link></button>
                            <button style={{backgroundColor: 'red', color: 'white'}}onClick={() => deletePirate(pirate._id)}>walk the plank</button>
                            </div>
                        </div>
                    )
                })
            }

            </div>

        </div>

    )
}

export default Display;